//
//  Colors.swift
//  homework-13
//
//  Created by Bauyrzhan Abdi on 15.05.2022.
//

import Foundation

enum Colors : Int {
    case red = 0, blue, green
}

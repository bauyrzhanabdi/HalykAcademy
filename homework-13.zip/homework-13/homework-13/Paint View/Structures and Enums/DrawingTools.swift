//
//  DrawingTools.swift
//  homework-13
//
//  Created by Bauyrzhan Abdi on 15.05.2022.
//

import Foundation

enum DrawingTools : Int {
    case pen = 0, rectangle, triangle, circle
}

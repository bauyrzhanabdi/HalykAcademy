import UIKit

// Задание 1
let height : Int = 10

// Печатаем боковые слэши
for i in 0 ..< height {
    for _ in 0 ..< (height-i-1) {print(" ", terminator: "")}
    for j in 0 ..< (i * 2 + 1) {
        if j == 0 {print("/", terminator: "")}
        if j == i * 2 {print("\\", terminator: "")}
        else {print(" ", terminator: "")}
    }
    print("")
}

// Печатаем дефис
for i in 0 ..< height * 2 {
    if i % 2 == 0 && i != height - 1 && i < height {print("-", terminator: "")}
    else if i % 2 != 0 && i > height {print("-", terminator: "")}
    else {print(" ", terminator: "")}
}
print("")

// Печатаем прямой слэш
for i in 0 ..< height * 2 {
    if i == height - 2 || i == height + 1 {print("|", terminator: "")}
    else {print(" ", terminator: "")}
}
print("")

// Печатаем пробел
for _ in 0 ..< height * 2 {print("-", terminator: "")}



// Задание 2
/*var num = 1

while num <= 150 {
    if (num >= 10 && num <= 99) && (num % 3 == 0) {
        print(num)
    }
    num += 1
}*/



// Задание 3
/*for num in 1...150 where num % 7 == 0 && num % 2 != 0 {
    print(num)
}*/
